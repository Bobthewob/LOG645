Les deux programmes s'ex�cutent le m�me fa�on, c'est-�-dire ./run.sh #prob valeurInit NbAlt�rations.

Pour la version parall�le, le nombre de processeurs est fixe et est de 64.